conda env create -f cmpt726-pytorch-python36.yml\
source activate cmpt726-pytorch-python36
python cifar_finetune.py
